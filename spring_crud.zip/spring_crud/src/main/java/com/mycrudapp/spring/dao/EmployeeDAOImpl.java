package com.mycrudapp.spring.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mycrudapp.spring.model.Employee;


@Repository// indicates that a class provides mechanism for CRUD ops 
public class EmployeeDAOImpl implements EmployeeDAO{
	// WE USE SPRING CONTAINER TO CREATE OBJECT FOR SESSION FACTORY
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public long save(Employee employee) {
		// TODO Auto-generated method stub
		//return 0;
		
		sessionFactory.getCurrentSession().save(employee);
		
		return employee.getId();
	}

	@Override
	public Employee get(long id) {
	
		return sessionFactory.getCurrentSession().get(Employee.class, id);
	}

	@Override
	public List<Employee> list() {
		
	List<Employee>list=sessionFactory.getCurrentSession().createQuery("from employee").list();
		
		return list;
	}

	@Override
	public void update(long id, Employee employee) {
		
	     Session session = sessionFactory.getCurrentSession();
	      Employee employee2 = session.byId(Employee.class).load(id);
	      employee2.setFirstname(employee.getFirstname());
	      employee2.setLastname(employee.getLastname());
	      employee2.setDob(employee.getDob());
	      employee2.setCurrentaddress(employee.getCurrentaddress());
	      employee2.setPermanentaddress(employee.getPermanentaddress());
	      employee2.setDepartment(employee.getDepartment());
	      employee2.setPhonenumber(employee.getPhonenumber());
	      employee2.setTrainingattended(employee.getTrainingattended());
	      session.flush();
		
		
	}

	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
	      Employee employee = session.byId(Employee.class).load(id);
	      session.delete(employee);
		
	}

}
