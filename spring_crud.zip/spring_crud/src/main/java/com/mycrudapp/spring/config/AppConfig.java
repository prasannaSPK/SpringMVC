package com.mycrudapp.spring.config;


import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;// better to choose from 5 instead of 2 or 3 since we r using ecllipse
import org.springframework.transaction.annotation.EnableTransactionManagement;
import static org.hibernate.cfg.Environment.*;

@Configuration  // saying spring that it is a configuration file.
@PropertySource("classpath:db.properties") // to tell where is our properties file located
@EnableTransactionManagement //to enable transactions
@ComponentScan("com.mycrudapp.spring")// scans all packages
public class AppConfig {
	//we need environment variable to read properties from properties file
	@Autowired
	private Environment env;

	/* localsessionfactory bean : to read properties from properties file & set them */
	// we can also do it by application context instead of bean factory
	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		
		LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
		
		Properties props = new Properties();
		//setting jdbc properties
		
		props.put(DRIVER,env.getProperty("mysql.driver"));
		props.put(URL,env.getProperty("mysql.url"));
		props.put(USER,env.getProperty("mysql.user"));
		props.put(PASS,env.getProperty("mysql.password"));
		
		//setting hibernate properties
		props.put(SHOW_SQL,env.getProperty("hibernate.show_sql"));
		props.put(HBM2DDL_AUTO,env.getProperty("hibernate.hbm2ddl.auto"));
		
		//setting c3p0 properties
		props.put(C3P0_MIN_SIZE,env.getProperty("hibernate.c3p0.min_size"));
		props.put(C3P0_MAX_SIZE,env.getProperty("hibernate.c3p0.max_size"));
		props.put(C3P0_ACQUIRE_INCREMENT,env.getProperty("hibernate.c3p0.acquire_increment"));
		props.put(C3P0_TIMEOUT,env.getProperty("hibernate.c3p0.timeout"));
		props.put(C3P0_MAX_STATEMENTS,env.getProperty("hibernate.c3p0.max_statements"));
		
		factoryBean.setHibernateProperties(props);
		// tables are created by hibernate so we h've to tell which packages they h've to scan
		factoryBean.setPackagesToScan("com.mycrudapp.spring.model");
		return factoryBean;
	}
	
	/* In hibernate we set hibernate factory transaction bean */
	@Bean
	public HibernateTransactionManager getTransactionManager() {
		HibernateTransactionManager  transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(getSessionFactory().getObject());
		
		return transactionManager;
	}
	
	
}
