package com.mycrudapp.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycrudapp.spring.dao.EmployeeDAO;
import com.mycrudapp.spring.model.Employee;


@Service //since it is a service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDAO employeeDAO;
	
	
	
	@Override
	@Transactional
	public long save(Employee employee) {
		// TODO Auto-generated method stub
		//return 0;
		
		return employeeDAO.save(employee);
	}

	@Override
	@Transactional
	public Employee get(long id) {
		// TODO Auto-generated method stub
		return employeeDAO.get(id);
	}

	@Override
	@Transactional
	public List<Employee> list() {
		// TODO Auto-generated method stub
		return employeeDAO.list();
	}

	@Transactional
	@Override
	public void update(long id, Employee employee) {
		// TODO Auto-generated method stub
		employeeDAO.update(id, employee);
		
	}

	@Transactional
	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		employeeDAO.delete(id);
	}

	
	
}
