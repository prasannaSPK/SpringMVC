package com.mycrudapp.spring.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="employee")//hibernate looks for the entity and creates table name employee
public class Employee {// note: the table_name created in mysql server will be small letters only
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)// it is like a primary key and auto increments
	private Long id;
	private String firstname;
	private String lastname;
	private String dob;
	private String permanentaddress;
	private String currentaddress;
	private String department;
	private Long phonenumber;
	private String trainingattended;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPermanentaddress() {
		return permanentaddress;
	}
	public void setPermanentaddress(String permanentaddress) {
		this.permanentaddress = permanentaddress;
	}
	public String getCurrentaddress() {
		return currentaddress;
	}
	public void setCurrentaddress(String currentaddress) {
		this.currentaddress = currentaddress;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Long getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getTrainingattended() {
		return trainingattended;
	}
	public void setTrainingattended(String trainingattended) {
		this.trainingattended = trainingattended;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", dob=" + dob
				+ ", permanentaddress=" + permanentaddress + ", currentaddress=" + currentaddress + ", department="
				+ department + ", phonenumber=" + phonenumber + ", trainingattended=" + trainingattended + "]";
	}
	
	
	
	
}
