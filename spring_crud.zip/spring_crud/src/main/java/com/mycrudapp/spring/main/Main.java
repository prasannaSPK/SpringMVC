package com.mycrudapp.spring.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mycrudapp.spring.config.AppConfig;





public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		context.close();

	}

}
